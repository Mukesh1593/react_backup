import React from 'react';
import ClearIcon from '@material-ui/icons/Clear';


const ItemList = (props) => {

	return (
		<>
			<div className="todo_style">
				<p className="delete_item" 
				onClick={() => {
					props.onSelect(props.id);
				}}>
				<ClearIcon /></p>
	 			<li>{props.text}</li>
	 		</div>
	 	</>
	);
};

export default ItemList;