import React from 'react';
import Cards from './Streamcards';
import Sdata from './Sdata';

const App = () => (
  <>
  <h3 className="style_css">Top Streaming On BookMyShow In 2021</h3>
  {Sdata.map((val, index) => {
  	return (
  		<Cards 
		   movieimg={val.movieimg} 
		   movietitle={val.movietitle} 
		   moviename={val.moviename}
		   movielink={val.movielink} 
		   />
  		);
  	})}
   </>
);

export default App;



// **************For BookMyShow Stream mini project with filter**************

/*import React from 'react';
import ReactDOM from 'react-dom';
import Cards from './Streamcards';
import Sdata from './Sdata';
import Action from './Action';
import Adventure from './Adventure';
import Horror from './Horror';

const favGener = "Action";

const App = () => {
if (favGener === "Action") {
		return (
            <Action />
           );
}
else if (favGener === "Adventure") {
	return (
            <Adventure />
           );
}
else {
	return(
		<Horror />
		);
}

};
export default App;*/

// **************With Ternary operater**************

/*const App = () => (
  <>
  <h1 className="style_css">Top Streaming On BookMyShow In 2021</h1>
   {<FavG />}
  {favGener === "Action" ? <Action /> : <Adventure /> }
   </>
);

export default App;*/

