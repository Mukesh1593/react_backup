const Sdata = [

	{
	movieimg: "https://in.bmscdn.com/iedb/movies/images/extra/vertical_logo/mobile/thumbnail/xxlarge/judas-and-the-black-messiah-et00136763-15-04-2021-10-07-48.jpg",
   	movietitle: "A BookMyShow Orignal Series",
   	moviegenre: "Drama",
   	moviename: "Judas And The Black Messiah",
   	movielink: "https://in.bookmyshow.com/movies/judas-and-the-black-messiah/ET00136763",
	},

	{
	movieimg: "https://in.bmscdn.com/discovery-catalog/events/et00309952-qerkjspfyg-portrait.jpg", 
   	movietitle: "A BookMyShow Orignal Series", 
   	moviegenre: "Adventure",
   	moviename: "The Witches", 
   	movielink: "https://in.bookmyshow.com/movies/the-witches-2020/ET00309952",
	},

	{
	movieimg: "https://in.bmscdn.com/iedb/movies/images/extra/vertical_logo/mobile/thumbnail/xxlarge/heroic-losers-et00145979-13-04-2021-04-42-01.jpg", 
   	movietitle: "A BookMyShow Orignal Series", 
   	moviegenre: "Adventure",
   	moviename: "Heroic Losers",
   	movielink: "https://in.bookmyshow.com/movies/heroic-losers/ET00145979",
	},


	{
	movieimg: "https://in.bmscdn.com/iedb/movies/images/extra/vertical_logo/mobile/thumbnail/xxlarge/zack-snyder-s-justice-league-et00047164-10-04-2021-03-22-49.jpg",
   	movietitle: "A BookMyShow Orignal Series",
   	moviegenre: "Action",
   	moviename: "Zack Snyder's Justice League",
   	movielink: "https://in.bookmyshow.com/movies/zack-snyders-justice-league/ET00047164",
	},

	{
	movieimg: "https://in.bmscdn.com/iedb/movies/images/extra/vertical_logo/mobile/thumbnail/xxlarge/tenet-et00121315-01-02-2021-11-11-05.jpg", 
   	movietitle: "A BookMyShow Orignal Series", 
   	moviegenre: "Action",
   	moviename: "Tenet", 
   	movielink: "https://in.bookmyshow.com/movies/tenet/ET00121315",
	},

	{
	movieimg: "https://in.bmscdn.com/iedb/movies/images/extra/vertical_logo/mobile/thumbnail/xxlarge/monster-hunter-et00301892-31-03-2021-05-55-34.jpg", 
   	movietitle: "A BookMyShow Orignal Series", 
   	moviegenre: "Action",
   	moviename: "Monster Hunter",
   	movielink: "https://in.bookmyshow.com/movies/monster-hunter/ET00301892",
	},

	{
	movieimg: "https://in.bmscdn.com/iedb/movies/images/extra/vertical_logo/mobile/thumbnail/xxlarge/tom-and-jerry-et00300988-01-04-2021-09-04-25.jpg", 
   	movietitle: "A BookMyShow Orignal Series", 
   	moviegenre: "Action",
   	moviename: "Tom & Jerry", 
   	movielink: "https://in.bookmyshow.com/movies/tom-jerry/ET00300988",
	},

	{
	movieimg: "https://in.bmscdn.com/iedb/movies/images/extra/vertical_logo/mobile/thumbnail/xxlarge/the-power-english-et00309248-07-04-2021-09-41-52.jpg", 
   	movietitle: "A BookMyShow Orignal Series", 
   	moviegenre: "Horror",
   	moviename: "The Power",
   	movielink: "https://in.bookmyshow.com/movies/the-power-english/ET00309248",
	},



];

export default Sdata;