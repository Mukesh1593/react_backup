import React from 'react';
import Sdata from './Sdata';
import Cards from './Streamcards';


const Action = () => {
    return (
        <>
            <Cards 
             movieimg={Sdata[3].movieimg} 
             movietitle={Sdata[3].movietitle}
             moviegenre={Sdata[3].moviegenre} 
             moviename={Sdata[3].moviename}
             movielink={Sdata[3].movielink} 
            />
            <Cards 
             movieimg={Sdata[4].movieimg} 
             movietitle={Sdata[4].movietitle}
             moviegenre={Sdata[4].moviegenre} 
             moviename={Sdata[4].moviename}
             movielink={Sdata[4].movielink} 
            />
            <Cards 
             movieimg={Sdata[5].movieimg} 
             movietitle={Sdata[5].movietitle}
             moviegenre={Sdata[5].moviegenre} 
             moviename={Sdata[5].moviename}
             movielink={Sdata[5].movielink} 
            />

            <Cards 
             movieimg={Sdata[6].movieimg} 
             movietitle={Sdata[6].movietitle}
             moviegenre={Sdata[6].moviegenre} 
             moviename={Sdata[6].moviename}
             movielink={Sdata[6].movielink} 
            />
        </>


    );
}

export default Action;