import React from 'react';
import Sdata from './Sdata';
import Cards from './Streamcards';


const Horror = () => {
	return (
            <Cards 
             movieimg={Sdata[7].movieimg} 
             movietitle={Sdata[7].movietitle}
             moviegenre={Sdata[7].moviegenre} 
             moviename={Sdata[7].moviename}
             movielink={Sdata[7].movielink} 
            />
           );
}

export default Horror;