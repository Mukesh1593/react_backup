

// Mini project for BookMyShow Stream with array & components

/*import React from 'react';
import ReactDOM from 'react-dom';
import Cards from './Streamcards';
import './index.css';
import Sdata from './Sdata';

ReactDOM.render(
  <>
  <h3 className="style_css">Top Streaming On BookMyShow In 2021</h3>

 <Cards movieimg={Sdata[0].movieimg} 
   movietitle={Sdata[0].movietitle} 
   moviename={Sdata[0].moviename}
   movielink={Sdata[0].movielink} 
   />

   <Cards movieimg={Sdata[1].movieimg} 
   movietitle={Sdata[1].movietitle} 
   moviename={Sdata[1].moviename}
   movielink={Sdata[1].movielink} 
   />

   <Cards movieimg={Sdata[2].movieimg} 
   movietitle={Sdata[2].movietitle} 
   moviename={Sdata[2].moviename}
   movielink={Sdata[2].movielink} 
   />

   <Cards movieimg={Sdata[3].movieimg} 
   movietitle={Sdata[3].movietitle} 
   moviename={Sdata[3].moviename}
   movielink={Sdata[3].movielink} 
   />

   <Cards movieimg={Sdata[4].movieimg} 
   movietitle={Sdata[4].movietitle} 
   moviename={Sdata[4].moviename}
   movielink={Sdata[4].movielink} 
   />

   <Cards movieimg={Sdata[5].movieimg} 
   movietitle={Sdata[5].movietitle} 
   moviename={Sdata[5].moviename}
   movielink={Sdata[5].movielink} 
   />


   </>,
 document.getElementById('root')
);*/



// Mini project for BookMyShow Stream with arrow function and map

import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';

ReactDOM.render(<App />, document.getElementById('root')
);