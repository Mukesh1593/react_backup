// Favourite Netflix Series


/*import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(
  <React.Fragment>
  <h1>Favourite Top 5 Netflix Web Series</h1>
  <p>Bellow are th list:</p>
  <ol>
    <li>Game Of Throne</li>
    <li>Stranger Things</li>
    <li>Narcos</li>
    <li>Money Heiest</li>
    <li>Khuda Hafeej</li>
  </ol>
  </React.Fragment>, 
  document.getElementById('root') ); */


// Date and Time

/*import React from 'react';
import ReactDOM from 'react-dom';

const name = "Mukesh";
const currDate = new Date().toLocaleDateString();
const currTime = new Date().toLocaleTimeString();


ReactDOM.render(
  <>
  <h1> My Name name is {name}</h1>
  <p>The Current Date is = {currDate}</p>
  <p>The Current Date is = {currTime}</p>
  </>,
  document.getElementById("root")
  );*/

  // JSX Attributes and css

  /*import React from "react";
  import ReactDOM from "react-dom";
  import "./index.css"

  const name = "Mukesh Patel";
  const img1 = "https://picsum.photos/200/300";
  const img2 = "https://picsum.photos/250/300";
  const img3 = "https://picsum.photos/300/300";
  const links = "https://www.google.com";

  ReactDOM.render(
      <>
      <h1 className="FName">My Name is : {name}</h1>
      <div className="img_id">
        <img src={img1} alt="SampleImage" />
        <img src={img2} alt="SampleImage" />
        <a href={links} target="_blank">
        <img src={img3} alt="SampleImage" />
        </a>
      </div>
      </>,
      document.getElementById('root')
    );
*/


//Inline css in react JSX

  /*import React from "react";
  import ReactDOM from "react-dom";
  import "./index.css"

  const name = "Mukesh Patel";
  const img1 = "https://picsum.photos/200/300";
  const img2 = "https://picsum.photos/250/300";
  const img3 = "https://picsum.photos/300/300";
  const links = "https://www.google.com";

const heading = {
  color: "#CC0000",
  fontWeight: "bold",
  padding: "10px 0",
  textAlign: "center",
  fontFamily: "'Roboto', sans-serif"

};

  ReactDOM.render(
      <>
      <h1 style={heading}>My Name is : {name}</h1>

      <div className="img_id">
        <img src={img1} alt="SampleImage" />
        <img src={img2} alt="SampleImage" />
        <a href={links} target="_blank">
        <img src={img3} alt="SampleImage" />
        </a>
      </div>
      </>,
      document.getElementById('root')
    );*/


// Greeting for Morning, Afternoon and Night

/*import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import DateTime from './DateTime';

ReactDOM.render( <DateTime />, document.getElementById("root"));*/


  // Creating components
  /*import React from 'react';
  import ReactDOM from 'react-dom';
  import App from './App';


  ReactDOM.render(
    
      <App />,
      document.getElementById('root')
    );*/

// Import and Export from components (Object, function)

/*import React from 'react';
import ReactDOM from 'react-dom';
import favmovies, {favGame, myName} from './ImportExport';

ReactDOM.render(
  <>
  <ol>
    <li>{favmovies}</li>
    <li>{favGame()}</li>
    <li>{myName()}</li>
  </ol>
  </>,
  document.getElementById('root')
  );*/

 // Calculation with components


 /*import React from 'react';
 import ReactDOM from 'react-dom';
 import App from './App';

 ReactDOM.render( <App />, document.getElementById('root')
   );*/


// Mini project for BookMyShow Stream with array & components

/*import React from 'react';
import ReactDOM from 'react-dom';
import Cards from './Streamcards';
import './index.css';
import Sdata from './Sdata';

ReactDOM.render(
  <>
  <h3 className="style_css">Top Streaming On BookMyShow In 2021</h3>

 <Cards movieimg={Sdata[0].movieimg} 
   movietitle={Sdata[0].movietitle} 
   moviename={Sdata[0].moviename}
   movielink={Sdata[0].movielink} 
   />

   <Cards movieimg={Sdata[1].movieimg} 
   movietitle={Sdata[1].movietitle} 
   moviename={Sdata[1].moviename}
   movielink={Sdata[1].movielink} 
   />

   <Cards movieimg={Sdata[2].movieimg} 
   movietitle={Sdata[2].movietitle} 
   moviename={Sdata[2].moviename}
   movielink={Sdata[2].movielink} 
   />

   <Cards movieimg={Sdata[3].movieimg} 
   movietitle={Sdata[3].movietitle} 
   moviename={Sdata[3].moviename}
   movielink={Sdata[3].movielink} 
   />

   <Cards movieimg={Sdata[4].movieimg} 
   movietitle={Sdata[4].movietitle} 
   moviename={Sdata[4].moviename}
   movielink={Sdata[4].movielink} 
   />

   <Cards movieimg={Sdata[5].movieimg} 
   movietitle={Sdata[5].movietitle} 
   moviename={Sdata[5].moviename}
   movielink={Sdata[5].movielink} 
   />


   </>,
 document.getElementById('root')
);*/



// Mini project for BookMyShow Stream with arrow function and map

import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';

ReactDOM.render(<App />, document.getElementById('root')
);