import React from 'react';
import Sdata from './Sdata';
import Cards from './Streamcards';


const Action = () => {
	return (
            <Cards 
             movieimg={Sdata[3].movieimg} 
             movietitle={Sdata[3].movietitle}
             moviegenre={Sdata[3].moviegenre} 
             moviename={Sdata[3].moviename}
             movielink={Sdata[3].movielink} 
            />
           );
}

export default Action;