const favmovie = "Kong Vs GodZilla";


function favGame(){
	let Game = 'Crickets';
	return Game;
}

function myName(){
	let myName = 'Patel Mukesh';
	return myName;
}
export default favmovie;

export {favGame, myName};