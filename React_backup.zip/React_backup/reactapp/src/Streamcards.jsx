import React from 'react';
import './index.css';

function Cards(props){

	return(
		<>
			<div className="bmsCards">
				<div className="bmsCard">
					<img src={props.movieimg} alt="myPic" className="bmsCard_img" />
					<div className="card_info">
						<span className="bmsCard_category">{props.movietitle}</span>
						<h3 className="title">{props.moviename}</h3>
						<div className="genre_info">
							<span className="genre">{props.moviegenre}</span>
						</div>
						<a href={props.movielink} target="_blank"> <button>Watch Now</button> </a>
					</div>
				</div>
			</div>
		</>
		);
}

export default Cards;