const Sdata = [

	{
	movieimg: "https://in.bmscdn.com/discovery-catalog/events/et00136763-pjgddezauj-portrait.jpg",
   	movietitle: "A BookMyShow Orignal Series",
   	moviegenre: "Drama",
   	moviename: "Judas And The Black Messiah",
   	movielink: "https://in.bookmyshow.com/movies/judas-and-the-black-messiah/ET00136763",
	},

	{
	movieimg: "https://in.bmscdn.com/discovery-catalog/events/et00309952-qerkjspfyg-portrait.jpg", 
   	movietitle: "A BookMyShow Orignal Series", 
   	moviegenre: "Adventure",
   	moviename: "The Witches", 
   	movielink: "https://in.bookmyshow.com/movies/the-witches-2020/ET00309952",
	},

	{
	movieimg: "https://in.bmscdn.com/discovery-catalog/events/et00145979-aemkycndfm-portrait.jpg", 
   	movietitle: "A BookMyShow Orignal Series", 
   	moviegenre: "Adventure",
   	moviename: "Heroic Losers",
   	movielink: "https://in.bookmyshow.com/movies/heroic-losers/ET00145979",
	},


	{
	movieimg: "https://in.bmscdn.com/discovery-catalog/events/et00047164-ndumsyxpnh-portrait.jpg",
   	movietitle: "A BookMyShow Orignal Series",
   	moviegenre: "Action",
   	moviename: "Zack Snyder's Justice League",
   	movielink: "https://in.bookmyshow.com/movies/zack-snyders-justice-league/ET00047164",
	},

	{
	movieimg: "https://in.bmscdn.com/discovery-catalog/events/et00121315-vkvlvxwebx-portrait.jpg", 
   	movietitle: "A BookMyShow Orignal Series", 
   	moviegenre: "Action",
   	moviename: "Tenet", 
   	movielink: "https://in.bookmyshow.com/movies/tenet/ET00121315",
	},

	{
	movieimg: "https://in.bmscdn.com/discovery-catalog/events/et00301892-gcdhfgcgdv-portrait.jpg", 
   	movietitle: "A BookMyShow Orignal Series", 
   	moviegenre: "Action",
   	moviename: "Monster Hunter",
   	movielink: "https://in.bookmyshow.com/movies/monster-hunter/ET00301892",
	},

	{
	movieimg: "https://in.bmscdn.com/discovery-catalog/events/et00300988-xbwbbjfjzw-portrait.jpg", 
   	movietitle: "A BookMyShow Orignal Series", 
   	moviegenre: "Action",
   	moviename: "Tom & Jerry", 
   	movielink: "https://in.bookmyshow.com/movies/tom-jerry/ET00300988",
	},

	{
	movieimg: "https://in.bmscdn.com/discovery-catalog/events/et00309248-eemkzxzpkf-portrait.jpg", 
   	movietitle: "A BookMyShow Orignal Series", 
   	moviegenre: "Horror",
   	moviename: "The Power",
   	movielink: "https://in.bookmyshow.com/movies/the-power-english/ET00309248",
	},



];

export default Sdata;