import React from 'react';
import Sdata from './Sdata';
import Cards from './Streamcards';


const Adventure = () => {
	return (
            <Cards 
             movieimg={Sdata[2].movieimg} 
             movietitle={Sdata[2].movietitle}
             moviegenre={Sdata[2].moviegenre} 
             moviename={Sdata[2].moviename}
             movielink={Sdata[2].movielink} 
            />
           );
}

export default Adventure;