import React from 'react';


function List() {
	return (
		<>
			<ul>
		        <li>Sultan</li>
		        <li>King Vs Godzilla</li>
		        <li>Coolie No.1</li>
		        <li>Hero</li>
		        <li>Dangal</li>
	      </ul>
		</>
		);
}

export default List;