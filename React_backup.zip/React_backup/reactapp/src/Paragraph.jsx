import React from 'react';

function Paragraph() {
	return (
			<p>My Best Movies List</p>
		);
}
	
export default Paragraph;