import React from 'react';


function DateTime() {
	let curDate = new Date();
 curDate = curDate.getHours();
let message = "";
const styleCSS = { };


 if (curDate >= 1 && curDate < 12) {
   message = "Good Morning!!";
   styleCSS.color= '#689F39';
 } else if (curDate >= 12 && curDate < 19) {
   message = "Good Afternoon!!";
   styleCSS.color= '#FC3156';
 } else {
   message = "Good Night!!";
   styleCSS.color= '#000';
 }

	return (
		<>
		    <div>
		      <h1>Hello Sir: <span style={styleCSS}> {message}</span></h1>
		    </div>
		  </>
		);
}

export default DateTime;