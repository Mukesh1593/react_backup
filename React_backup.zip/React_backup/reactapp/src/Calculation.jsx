function add(a, b) {
	let sum = a+b;
	return sum;
}

function subs(a, b){
	let sum = a-b;
	return sum;
}

function multiflication(a, b){
	let sum = a*b;
	return sum;
}

function division(a, b){
	let sum = a/b;
	sum = sum.toFixed(2);
	return sum;
}
export {add, subs, multiflication, division};