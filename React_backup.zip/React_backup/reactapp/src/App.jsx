// For Calculation component

/*import React from 'react';
import Heading from './Heading';
import Paragraph from './Paragraph'
import List from './List';
import {add, subs, multiflication, division} from './Calculation';


function App() {
	return(
		<>
			<Heading />
			<Paragraph />
			<List />

			<ul>
	         <li>{add(50, 5)}</li>
	         <li>{subs(55, 5)}</li>
	         <li>{multiflication(50, 5)}</li>
	         <li>{division(55, 7)}</li>
	       </ul>
		</>
		);
}

export default App;*/


// **************For BookMyShow Stream mini project**************

/*import React from 'react';
import ReactDOM from 'react-dom';
import Cards from './Streamcards';
import Sdata from './Sdata';
import Action from './Action';
import Adventure from './Adventure';
import Horror from './Horror';

const favGener = "Action";

const FavG = () => {
if (favGener === "Action") {
		return (
            <Action />
           );
}
else if (favGener === "Adventure") {
	return (
            <Adventure />
           );
}
else {
	return(
		<Horror />
		);
}

};*/


// **************With Ternary operater**************

/*const App = () => (
  <>
  <h1 className="style_css">Top Streaming On BookMyShow In 2021</h1>
  // {<FavG />}
  {favGener === "Action" ? <Action /> : <Adventure /> }
   </>
);

export default App;*/


// **************Mini project for Slote Game**************

/*import React from 'react';

const SlotM = (props) => {


	let x = props.x;
	let y = props.y;
	let z = props.z;

	if ( x === y && y === z) {
		return (
			<>
				<div className="slot_inner">
					<h1>
						{x} {y} {z}
					</h1>
					<h1>This is matching.</h1>
					<hr />
				</div>
			</>
		);
	}
	else {
		return (
			<>
				<div className="slot_inner">
					<h1>
						{x} {y} {z}
					</h1>
					<h1>This is Not matching.</h1>
					<hr />
				</div>
			</>
		);
	}
};

const App = () => {
	return(
		<>
		<h1 className="headling_style"> &#127920; Welcome to <span> Slot machine game </span> &#127920;</h1>
		<div className="slotmachine">
			<SlotM x="😄" y="😄" z="😄" />
			<SlotM x="💗" y="😄" z="🤪" />
			<SlotM x="😄" y="😄" z="😄" />
		</div>
		</>

		);
}

export default App;*/


// **************Hooks with increment on click**************

/*import React, { useState } from 'react';


const App = () => {
	const state = useState();
	const [count, setCount] = useState(0);

	const IncNum = () => {
		setCount(count + 1);

	};
	return(
		<>
			<div className="incronbutton">
				<h1>{count}</h1>
				<button onClick={IncNum}>Click Me</button>
			</div>
		</>
		);
};

export default App;*/



// **************Local Time on click button**************

/*import React, { useState } from 'react';

const App = () => {

	let ctime = new Date().toLocaleTimeString();

	const [time, newTime] = useState (ctime);

	const MainTime = () => {
		ctime = new Date().toLocaleTimeString();
		newTime(ctime);
	};

	return (
		<>
			<div className="incronbutton">
				<h1>{time}</h1>
				<button onClick={MainTime}>Click Here</button>
			</div>
		</>
		);
};

export default App;*/



// **************Local Time with setInterval**************

/*import React, { useState } from 'react';

const App = () => {
	let currTime = new Date().toLocaleTimeString();

	const [LocTime, UpdateTime] = useState(currTime);

	const MainUpdatedTime = () => {
		currTime = new Date().toLocaleTimeString();
		UpdateTime(currTime);
	};
	setInterval(MainUpdatedTime, 1000);
	return (
				<h1>{LocTime}</h1>
		);
};

export default App;*/



// **************Click Events**************

/*import React, { useState } from 'react';

const App = () => {

	const BgColor = 'red';
	const [bg, setNewBg] = useState(BgColor);

	const BtnColor = '#000';
	const [btnbg, newBtnBg] = useState(BtnColor);

	const [text, setText] = useState('Click Here');

	const bgChange = () => {
		let newBg = 'yellow';
		setNewBg(newBg);

		setText('Haye!! 💗');

		let buttunColor = 'red';
		newBtnBg(buttunColor);

	};

	const bgBack = () => {
		let bg1 = 'green';
		setNewBg(bg1);
		setText('Ohh No 🤪');

		let buttunColor1 = 'yellow';
		newBtnBg(buttunColor1);
	};


	return (
		<div style={{backgroundColor:bg }}>
			<button onClick={bgChange} onDoubleClick={bgBack}>{text}</button>
			<button style={{backgroundColor:btnbg }} onMouseOver={bgChange} onMouseOut={bgBack}>{text}</button>
		</div>
		);
};

export default App;*/




// **************Create Form Feild**************


import React, { useState } from 'react';



const App = () => {

	const [name, newName] = useState();

	const [fullName, updatedName] = useState();

	const [Pass, newPass] = useState();

	const [userPass, newUserPass] = useState('');


	const inputEvent = (text) => {
		newName(text.target.value);
	};

	const inputPass = (pass) => {
		newPass(pass.target.value);
	};

	const inputDetails = (event) => {
		event.preventDefault();
		updatedName(name);
		newUserPass(Pass);
	}

	return(
		<>
			<div>
			<form onSubmit={inputDetails} >
				<h2>Hello {fullName} {userPass}</h2>
				<input type="text" placeholder="Enter Username" onChange={inputEvent} value={name} />
				<input type="Passward" placeholder="Enter Passward" onChange={inputPass} value={Pass} />
				<button type="submit" className="btn">Submit</button>
				</form>
			</div>
		</>
		);
};

export default App;