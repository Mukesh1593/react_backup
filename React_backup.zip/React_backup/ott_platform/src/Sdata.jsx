import altbalaji from "../src/images/altbalaji.png";
import arre from "../src/images/arre.png";
import bigflix from "../src/images/bigflix.png";
import hotstar from "../src/images/hotstar.png";
import netflix from "../src/images/netflix.png";
import prime from "../src/images/prime.png";
import voot from "../src/images/voot.png";
import zee5 from "../src/images/zee5.png";

const Sdata = [
    {
        imgsrc : netflix,
        title : "Netflix",
        ottlink: "https://www.netflix.com/in/",
        desciption: "Explore the latest Web Series and Blockbusters Movies on NETFLIX",
    },
    {
        imgsrc : prime,
        title : "Amazon Prime",
        ottlink: "https://www.primevideo.com/",
        desciption: "Explore the latest Web Series and Blockbusters Movies on Amazon Prime",

    },
    {
        imgsrc : zee5,
        title : "Zee5",
        ottlink: "https://www.zee5.com/",
        desciption: "Explore the latest Web Series and Blockbusters Movies on ZEE5",
    },
    {
        imgsrc : voot,
        title : "Voot Select",
        ottlink: "https://www.voot.com/",
        desciption: "Explore the latest Web Series and Blockbusters Movies on Voot",
    },
    {
        imgsrc : hotstar,
        title : "Disney Hotstar",
        ottlink: "https://www.hotstar.com/in",
        desciption: "Explore the latest Web Series and Blockbusters Movies on Hotstar",
    },
    {
        imgsrc : altbalaji,
        title : "Alt Balaji",
        ottlink: "https://www.altbalaji.com/",
        desciption: "Explore the latest Web Series and Blockbusters Movies on AltBalaji",
    },
    {
        imgsrc : arre,
        title : "Arré",
        ottlink: "https://www.arre.co.in/",
        desciption: "Explore the latest Web Series and Blockbusters Movies on Arre",
    },
    {
        imgsrc : bigflix,
        title : "BigFlix",
        ottlink: "https://www.bigflix.com/",
        desciption: "Explore the latest Web Series and Blockbusters Movies on BigFlix",
    },
]

export default Sdata;