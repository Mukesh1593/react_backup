import React from "react";

const Service = (props) => {

    return(
        <h1>This is {props.name} Page.</h1>
    )
};

export default Service;