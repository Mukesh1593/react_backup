import React, { useContext } from 'react';
import CompC from './CompC'
import { OfficeName, City } from './App';

const CompB = () => {

    const OffName = useContext(OfficeName);
    const CityName = useContext(City);

    return (
        <h1>Hello, This is Mukesh Patel from {OffName} {CityName} </h1>

    )
};

export default CompB;