//*********Context API, useContext*********

/* import React, { createContext } from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import CompA from './CompA';

const OfficeName = createContext ();
const City = createContext ();

const App = () => {
	return (
		<>
		<OfficeName.Provider value={"BookMyshow"}>
		<City.Provider value={"Mumbai"}>
		<CompA />
		</City.Provider>
		</OfficeName.Provider>
		</>
	);
};

export default App;
export { OfficeName, City }; */



// *********useEffect*********

/* import React, { useEffect, useState } from 'react';

const App = () => {

	const [num, setNum] = useState(0);
	const [nums, setNums] = useState(0);

	// useEffect (() => {
		alert('You cliked me')
	}, [num]);

	useEffect(() => {
		document.title= `You Clicked me ${nums} Times`
	})

	//const Incr = () => {
		//setNum (num + 1);
	//};


	
	// inline function 

	return (
		<>
		<button onClick={()=> {setNum(num+1)}}>Click Me {num}</button>
			
		<br/> 
		<button onClick={()=> {setNums(nums+1)}}>Click Me {nums}</button>
		</>
	)

};

export default App; */


//*********React Router*********

/* import React from 'react';
import { Route, Switch } from 'react-router-dom';
import Contact from './Contact';
import AboutUs from './AboutUs';
import Error from './Error';



const App  = () => {
	return(
		<>
		<Switch>
			<Route exact path='/' component={AboutUs} />
			<Route path='/contact' component={Contact} />
			<Route component={Error} />
		</Switch>
	</>
	)

};

export default App; */


//*********Create Menu/NavBar********

/*
import React from 'react';
import { Route, Switch } from 'react-router-dom';
import Contact from './Contact';
import AboutUs from './AboutUs';
import Service from './Service';
import Menu from './Menu';

const App = () => {
	return(
		<>
		<Menu />
		<Switch>
			<Route exact path='/' component={AboutUs} />
			<Route exact path='/contact' component={Contact} />
			<Route path='/Service' component={Service} />
			<Route component={Error} />
		</Switch>
		</>
	)
};

export default App; */



//*********React Route Render Method********


import React from 'react';
import { Route, Switch } from 'react-router-dom';
import Contact from './Contact';
import AboutUs from './AboutUs';
import Service from './Service';
import Search from './Search';
import Menu from './Menu';

const App = () => {
	return(
		<>
		<Menu />
		<Switch>
			<Route exact path='/' component={() => <AboutUs name="AboutUs" />} />
			<Route exact path='/search' component={Search} />
			<Route path='/service' render={() => <Service name="Service" /> } />
			<Route exact path='/contact' component={Contact} />
			<Route component={Error} />
		</Switch>
		</>
	)
};

export default App;