import React from 'react';


const AboutUs  = (props) => {
	return(
	<h1>This is {props.name} Us Page.</h1>
	)

};

export default AboutUs;