import React from 'react';
import {NavLink} from 'react-router-dom';


const Menu = () => {
	return(
		<>
        <div className="nav_bar">
        <NavLink exact activeClassName="class_name" to="/">
        AboutUs
        </NavLink>
        <NavLink exact activeClassName="class_name" to="/search">
        Search
        </NavLink>
        <NavLink exact activeClassName="class_name" to="/service">
        Service
        </NavLink>
        <NavLink exact activeClassName="class_name" to="/contact">
        Contact
        </NavLink>
        </div>
		</>
	)
};

export default Menu;