import React from 'react';
import { OfficeName, City } from './App';

const CompC = () => {
    return (
        <>
        <OfficeName.Consumer> 
        {(cname) => {
            return (
            <City.Consumer>
                {(ctname) => {
                    return <h1>Hello, This is Mukesh Patel {cname} {ctname} </h1>
                }}
            </City.Consumer>
            )
        }}
        </OfficeName.Consumer>
        </>
    );
};

export default CompC;