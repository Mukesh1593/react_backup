import React from 'react';
import ThemedDigitalClock from 'themed-digital-clock';

const DigitalClockNpm = () => {
	return(
		<ThemedDigitalClock
          
          useDarkTheme={true} size={300}/>
		)
};

export default DigitalClockNpm;