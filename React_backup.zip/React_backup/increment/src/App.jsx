import React, { useState } from 'react';
import AddIcon from '@material-ui/icons/Add';
import DeleteIcon from '@material-ui/icons/Delete';
import Tooltip from '@material-ui/core/Tooltip';
import Button from '@material-ui/core/Button';


const App = () => {

	const [num, setNum] = useState(0);

	const Incre = () => {
		setNum (num + 1);

	};

	const Decre = () => {
		if (num > 0) {
		setNum (num - 1);
	} else {

		alert ("Sorry, You Have Reached Zero Limit");
		setNum(0);
	}
	};

	return(
	<>
		<div className="main_div">
			<div className="center_div">
				<h1>{num}</h1>
				<div className="btn_div">
					<button className="increment" onClick={Incre}>Incr</button>
					<button className="decrement" onClick={Decre}>Decr</button>
				</div>
			</div>
		</div>
	</>
	);
};

export default App;