import React from 'react';


const Footer = () => {

	const Year = new Date().getFullYear();

	return(
		<>
			<div>
				<footer>
					<p>Copyright © {Year} </p>
				</footer>
			</div>
		</>
		);
};

export default Footer;



